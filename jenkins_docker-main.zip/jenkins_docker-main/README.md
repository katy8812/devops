# jenkins_docker
Ejemplo de generación de imagen docker desde Jenkins
